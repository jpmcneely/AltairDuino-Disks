/*  URLReader.m: read the contents of an URL into memory

 Requires Cocoa support

 Copyright (c) 2002-2014, Peter Schorn

 Permission is hereby granted, free of charge, to any person obtaining a
 copy of this software and associated documentation files (the "Software"),
 to deal in the Software without restriction, including without limitation
 the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 PETER SCHORN BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 Except as contained in this notice, the name of Peter Schorn shall not
 be used in advertising or otherwise to promote the sale, use or other dealings
 in this Software without prior written authorization from Peter Schorn.

*/

#ifdef URL_READER_SUPPORT

#import <Cocoa/Cocoa.h>
#include "sim_defs.h"

uint8 *URLContents(const char *URL, uint32 *length);

/*  Input:  URL     - the URL to be read
    Output: length  - the number of bytes in the return memory area. 0 if an
            error occurred.
            The return value is a memory area on the heap containing the
            contents of the URL. The caller is responsible for freeing the
            memory area after use.
*/

uint8 *URLContents(const char *URL, uint32 *length) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSString *theString = [[NSString alloc] initWithBytes:URL
                                                   length:strlen(URL)
                                                 encoding:NSASCIIStringEncoding];
    NSData *theData = [NSData dataWithContentsOfURL:[NSURL URLWithString:theString]];
    [theString release];
    if ((theData == nil) || ([theData length] == 0)) {
        *length = 0;
        [pool drain];   // releases the pool
        return NULL;
    }
    uint8 *result = malloc([theData length]);
    [theData getBytes:result length:[theData length]];
    *length = [theData length];
    [pool drain];       // releases the pool
    return result;
}

#endif
